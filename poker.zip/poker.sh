#!/bin/bash

make playable
wait
dir=\"$(pwd)\"
alias playpoker="$dir/main.byte"