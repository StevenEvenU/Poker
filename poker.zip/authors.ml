let hours_worked_Elias = 21

let hours_worked_Zach = 19

let hours_worked_Steven = 20
