let hours_worked_Elias_1 = 21

let hours_worked_Zach_1 = 19

let hours_worked_Steven_1 = 20

let hours_worked_Elias_2 = 10

let hours_worked_Zach_2 = 8

let hours_worked_Steven_2 = 5

let hours_worked_Elias_3 = 25

let hours_worked_Zach_3 = 17

let hours_worked_Steven_3 = 25
